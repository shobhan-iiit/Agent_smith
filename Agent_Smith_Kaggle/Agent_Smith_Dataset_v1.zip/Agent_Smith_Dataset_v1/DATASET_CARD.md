# Dataset card

## Scope and provenance

Procedurally generated, fictional, English-only Agent Smith policy-compliance data. No real customer records, external scraped conversations or human-authored labels are included. Seed: `20261027`. Family definitions and all generation logic are provided. There are 36 policy-template families across authorization, artifact checks, destinations, data governance, operations and financial/access control.

The 720 base scenarios are parameterized template instances. They are **not 720 independently authored workflows**. Each family contains eight safe/unsafe counterfactual pairs and four unresolved cases. Versions, recipients, amounts, purposes, clocks, permitted values and evidence positions vary. Every base scenario has 8-, 16- and 32-event renderings in the same split.

## Semantics

Policy requirements use explicit operators: equality, set membership, containment, lower/upper bounds, field-set coverage, universal equality, distinct-signer thresholds, maintenance windows and age limits. Each event is keyed by resource, scope, version and attribute. Newer evidence revisions supersede older matching revisions. Same-revision disagreement and unavailable evidence are unresolved. A known violated requirement blocks even if another requirement is unresolved; permission requires every requirement to pass.

Evidence records link to newer and concurrent records using metadata computed from the visible log. Selecting an old record while omitting a known update produces `defer`. These links are an engineered provenance feature, not a hidden label. Their usefulness must be ablated separately if making claims about history reasoning. H2/H3/H4 pack complete temporal field groups; H1 keeps the recent suffix. Report grouping effects separately from ranking effects.

Untrusted external text cannot authorize actions. Distractors include wrong scopes, wrong artifact versions and unrelated documents containing instructions. Counterfactual pairs differ in one current evidence value; stability pairs change irrelevant text while preserving policy state.

## Splits

24 training, 6 validation and 6 test families, with each domain represented. Held-out families use different requirements/tools while sharing a small policy grammar. This measures synthetic policy-template transfer, not unrestricted real-world agent generalization. Family IDs, scenario IDs, private labels and oracle evidence must not be included in model inputs. Related pairs and history renderings stay in one split.

Test cases are packaged separately and intended to remain unused until model settings are frozen. The generator makes the test reconstructible, so this is an experimental protocol rather than access control. This new test has not been used for model selection. The earlier pilot validation is not reused as a final test.

## Labels and sufficiency

Full-history labels are `allow=0`, `block=1`, `defer=2`. `violates` is true only for known block cases; unresolved is tracked separately. Monitor-context labels are evidence-relative and may be `defer` even when full history proves allow/block. Preserve both labels when computing detection or safe-completion metrics.

For known allow/block cases, private `sufficient_sets` enumerate minimal groups of evidence fields whose complete revision chains reproduce the full verdict. Multiple valid sufficient sets are retained. Unresolved cases have no decisive allow/block sufficient set: coverage is `null`, not a misleading perfect score for an empty history. Relevance labels for unresolved cases identify matching records needed to recognize uncertainty, not hidden proof of safety.

## Retrieval and training

5,760 selector examples use the shortest rendering once per base scenario to reduce duplicate weighting. Policy retrieval has 720 queries with one relevant rule passage each and 108 candidate passages. The one-relevant-passage assumption is a pilot simplification; multi-policy RAG remains future expansion.

H0/H1/H2 and oracle context exports use approximate word packing and are marked accordingly. `prepare_model_data.py` regenerates training/validation H0/H1/H2 using the actual tokenizer, checks the entire 512-token input and rejects silent truncation. It exports oracle validation separately. H3/H4 require out-of-fold learned scorers and are not generated as if a model had been trained.

Raw context counts include repeated scenarios. Use family- or base-scenario-level uncertainty estimates, not independent-row assumptions. H0's correct deferrals do not imply successful task completion. No model accuracy, calibration, live task success or protocol advantage is claimed by this dataset release.

## Evaluation fixtures

48 live task fixtures have bounded investigation, a mix of complete and partial visible histories, scoped read-only query options, private tool responses and expected final verdicts. 192 tool cases cover valid calls, missing arguments, out-of-scope resources and injected transient errors. These are predefined fixtures; no real failure frequency is estimated. 144 handoff representations hold payload information fixed across free text, JSON and shared-state reference formats; they are not implementations or benchmarks of A2A versus MCP.

## Validation and limitations

Automated checks cover unique IDs, family/base separation, exact text separation, full-history oracle replay, sufficient-set replay, single-value counterfactual differences and labels on identical contexts. Behavioral tests independently specify example outcomes for known temporal and scope boundaries. The generator and oracle share policy definitions, so agreement is not independent evidence of label correctness.

All labels are **provisional**. Human review, richer narratives, broader information-provenance graphs, cross-policy interactions, real tool behavior and independent final testing remain necessary. Rules can solve this structured benchmark directly: include a deterministic full-history policy baseline and report the learned monitor's incremental value honestly.
