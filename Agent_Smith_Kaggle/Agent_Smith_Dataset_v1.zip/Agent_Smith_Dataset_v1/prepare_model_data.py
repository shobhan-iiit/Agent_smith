"""CPU-only MiniLM data export. No training or GPU required.

Run after label review. Uses the real tokenizer and rejects oversize inputs.
Never opens sealed test data or treats oracle contexts as monitor training data.
"""
import argparse
import json
from pathlib import Path
import dataset as d


def read(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("development"))
    parser.add_argument("--output", type=Path, default=Path("model_data"))
    parser.add_argument("--tokenizer", default="microsoft/MiniLM-L12-H384-uncased")
    args = parser.parse_args()
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer)
    counter = lambda text: len(tokenizer.encode(text, add_special_tokens=True))
    if args.output.exists() and any(args.output.iterdir()):
        raise ValueError("Use a new output directory; do not overwrite an existing training snapshot")
    stats = {}
    for split in ["train", "validation"]:
        cases = read(args.data / split / "public/cases.jsonl")
        labels = {r["case_id"]: r for r in read(args.data / split / "private/labels.jsonl")}
        contexts = d.emit_contexts(cases, labels, args.output / "monitor" / f"{split}.jsonl",
            variants=["H0", "H1", "H2"], counter=counter, max_tokens=512)
        # Never truncate selector evidence or leak its relevance label into text.
        pairs = read(args.data / split / "selector/pairs.jsonl")
        for pair in pairs:
            if counter(pair["text"]) > 512:
                raise ValueError("Oversize selector input: " + pair["case_id"])
        d.write_jsonl(args.output / "selector" / f"{split}.jsonl", pairs)
        if split == "validation":
            d.emit_contexts(cases, labels, args.output / "evaluation_only/oracle_validation.jsonl",
                variants=["oracle"], counter=counter, max_tokens=512)
        stats[split] = dict(monitor_rows=len(contexts), selector_pairs=len(pairs),
            max_monitor_tokens=max(counter(row["text"]) for row in contexts))
    manifest = dict(tokenizer=args.tokenizer, max_tokens=512, splits=stats,
        monitor_variants=["H0", "H1", "H2"], oracle_training_rows=0,
        trained_selector_contexts="H3/H4 require cross-fitted scorer; not synthesized",
        review_status="provisional until team review", final_test_used=False)
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
