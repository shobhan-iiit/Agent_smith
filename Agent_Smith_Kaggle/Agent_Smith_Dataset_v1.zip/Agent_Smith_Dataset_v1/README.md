# Agent Smith dataset v1

This is a new synthetic research-development corpus, not an extension to concatenate blindly with the 108-case pilot. It covers the planned raw-data categories and includes reproducible generation, labels, review sheets, model-data exports and evaluation fixtures. **Every generated label is provisional until reviewed.**

## Counts

| Item | Train | Validation | Held-out test | Total |
|---|---:|---:|---:|---:|
| Policy-template families | 24 | 6 | 6 | 36 |
| Base scenarios | 480 | 120 | 120 | 720 |
| Cases at lengths 8, 16, 32 | 1,440 | 360 | 360 | 2,160 |
| Selector action/event pairs | 3,840 | 960 | 960 | 5,760 |
| H0/H1/H2 monitor contexts | 4,320 | 1,080 | 1,080 | 6,480 |
| Oracle contexts, evaluation only | 1,440 | 360 | 360 | 2,160 |
| Counterfactual safe/unsafe pairs | 576 | 144 | 144 | 864 |
| Irrelevant-instruction stability pairs | 48 | 12 | 12 | 72 |
| Live-agent task fixtures | 32 | 8 | 8 | 48 |
| Tool-call/error fixtures | 128 | 32 | 32 | 192 |
| Handoff-format fixtures | 96 | 24 | 24 | 144 |
| Policy retrieval queries | 480 | 120 | 120 | 720 |

The shared retrieval corpus contains **108 policy passages**. Repeated renderings, paired cases, handoff formats and tool errors are correlated examples, not additional independent workflows.

## Start here — no GPU required

1. Extract this package. Keep `sealed_test/Agent_Smith_Heldout_Test.zip` closed during development.
2. Read `DATASET_CARD.md` and `REVIEW_GUIDE.md`.
3. Run the standard-library checks from this directory:

```bash
python -m unittest -v test_dataset
python dataset.py validate --data development
```

4. Start review with `development/train/review.csv` and the corresponding `public/cases.jsonl`. Check the eight matched safe/unsafe base pairs plus four unresolved base cases per family. Inspect additional history lengths when event placement could matter.
5. After review, export MiniLM-compatible inputs on **CPU**:

```bash
python -m pip install transformers
python prepare_model_data.py --data development --output model_data_v1
```

The tokenizer may download once; training is not run. `model_data_v1/monitor/train.jsonl` and `validation.jsonl` have the familiar `text`, `label`, `split`, `family_id` fields. Selector files use the same record convention. Do not use `*_approx.jsonl` directly for training: those use approximate word packing, not MiniLM tokens.

## Layout and boundaries

- `development/train` and `development/validation`: observations, private evaluator labels, selector pairs, approximate contexts, policy queries, review CSVs, robustness and live-agent fixtures.
- `development/policy_corpus.jsonl`: public policy knowledge available at retrieval time, including unseen-family policies. It contains no scenario verdicts.
- `development/crossfit_folds.json`: three family-disjoint selector folds, with separate internal checkpoint-validation families. Excluded families must not choose a fold checkpoint.
- `sealed_test/Agent_Smith_Heldout_Test.zip`: final cases and labels packaged separately. This is a procedural holdout, not encrypted secrecy; the generator can reconstruct it.
- `dataset.py`: deterministic generator, policy oracle, BM25 selection, temporal grouping, renderer and validators.
- `prepare_model_data.py`: exact-tokenizer exports for development training. Test data is never read.
- `test_dataset.py`: behavioral tests for temporal rules, conflicts, scope and version matching.

## What is deliberately not claimed

- No human review or trained-model performance is fabricated.
- H3/H4 learned contexts cannot be finalized without trained selectors. `selected_events(..., scorer=...)` supports them; training contexts must use out-of-fold scorers. Oracle evidence is never a training context or runtime selector input.
- The old Colab pilot's `Observation`/`Proposal` classes do not directly accept this richer schema. Use the provided text exports with the full-monitor training code; a structured live-agent adapter remains implementation work.
- The 48 live tasks and 192 tool cases are fixtures, not completed live-agent runs. Tool calls and handoffs still need an execution harness.
- Training-only families remain disjoint from validation/test. Template operators and policy grammar are intentionally shared and the task remains synthetic.

## Reproduce the complete corpus

```bash
python dataset.py generate --output regenerated_corpus
python dataset.py validate --data regenerated_corpus
```

Do not regenerate/open final test examples as part of iterative model development. Freeze models and settings first, then use an independent test evaluation. Review corrections require a new version and fresh checksums; do not silently edit a dataset used by a saved checkpoint.
