# Team review checklist

No GPU is needed. Assign training/validation families among team members. Keep final test review separate from model tuning; an evaluator can review it without revealing failures to the training team.

## First pass

- [ ] Read the dataset card and agree on allow/block/defer semantics.
- [ ] Assign all 24 training families and 6 validation families for review.
- [ ] Start with one allow, one block and both unresolved subtypes per family.
- [ ] Check evidence matching uses resource, scope and version before choosing a revision.
- [ ] Check grants followed by denials and denials followed by grants.
- [ ] Check wrong-recipient and wrong-version updates cannot change authorization.
- [ ] Check equality/boundary cases, missing data and conflicting same-revision reports.
- [ ] Check every required field for multi-condition permission; one known violation can block.
- [ ] Check untrusted instructions remain irrelevant to authorization.

## Full base-scenario review

Each `review.csv` row represents a base scenario at eight events. Open the matching record in `public/cases.jsonl`; private labels and sufficient evidence are under `private/`. The 16-/32-event variants share the same state but should be checked when placement or linked revisions matter.

- [ ] Reviewer writes their verdict before comparing with the proposed label where practical.
- [ ] Mark reviewer identity, approved status, corrected label if needed and reasoning.
- [ ] Confirm the decisive field groups; do not merely accept the generated verdict.
- [ ] Confirm each paired case differs only in the intended evidence value.
- [ ] Mark ambiguous policy language for clarification instead of forcing agreement.
- [ ] A second reviewer checks disagreements and a sample of agreements.
- [ ] Record any generator/schema correction as a new dataset version.
- [ ] Regenerate and rerun checks after fixes. Keep the previous version/checksums.

## Model-data readiness

- [ ] Record review coverage: reviewed rows / total base rows, by family and label.
- [ ] Resolve known disagreements before training on affected cases.
- [ ] Generate exact-tokenizer exports on CPU; never truncate decisive evidence.
- [ ] Keep full-history ground truth separate from selected-context targets.
- [ ] Exclude oracle rows from monitor training and runtime selection.
- [ ] Use cross-fitted selectors for H3/H4 training contexts; never score held-out families with a selector trained on their labels.
- [ ] Bind each checkpoint to dataset and tokenizer hashes.
- [ ] Do not inspect final test predictions until configuration is frozen.

Next implementation step after review: connect the exact text exports to full-monitor training, then train the selector on this schema and regenerate H3/H4 contexts. The existing pilot notebook must be adapted; simply uploading this archive as the old bundle will not work.
