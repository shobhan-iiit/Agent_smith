"""Print a training/validation family for human review, blinded by default."""
import argparse
import json
from pathlib import Path
import dataset as d


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("development"))
    parser.add_argument("--split", choices=["train", "validation"], default="train")
    parser.add_argument("--family", required=True)
    parser.add_argument("--show-labels", action="store_true")
    args = parser.parse_args()
    root = args.data / args.split
    cases = [json.loads(line) for line in (root / "public/cases.jsonl").read_text().splitlines()]
    labels = {r["case_id"]: r for r in map(json.loads, (root / "private/labels.jsonl").read_text().splitlines())} if args.show_labels else {}
    selected = [c for c in cases if c["family_id"] == args.family and len(c["events"]) == 8]
    if not selected: raise ValueError("Family not found in this split")
    print("# Human review: " + args.family)
    for case in selected:
        print("\n## " + case["base_case_id"] + "\n")
        print("```text\n" + d.render(case, case["events"]) + "\n```\n")
        print("Reviewer verdict: ____  Decisive evidence: ____  Notes: ____\n")
        if args.show_labels:
            label = labels[case["case_id"]]
            print("Proposed label: **" + label["verdict"] + "**\n")
            print("Generated sufficient sets: " + json.dumps(label["sufficient_sets"]) + "\n")


if __name__ == "__main__":
    main()
